<template>
  <div class="">
    <router-view></router-view>
  </div>
</template>

<script>
  export default{
    components: {
    },
    name: '',
    data () {
      return {
        msg: ''
      }
    }
  }
</script>
