<template>
  <div class="">
    <router-view></router-view>
  </div>
</template>
<style lang="less" scoped></style>
<script>

  export default{
    name: '',
    data () {
      return {
        msg: ''
      }
    }
  }
</script>
