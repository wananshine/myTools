<template>
	<div>手机</div>
</template>

<style  scoped lang="less">
	
</style>

<script type="text/javascript">
	export default{
		name: '',
		data() {
			return{

			}
		},
		mounted: function(){
			this.$nextTick(function(){

			})
		},
	}
</script>