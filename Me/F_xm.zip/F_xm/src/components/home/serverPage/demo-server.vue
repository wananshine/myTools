<template>
  <div class="">
    <router-view></router-view>
  </div>
</template>
<style lang="less" scoped="scoped"></style>
<script>
  
  export default{
    components: {
      
    },
    name: '',
    data () {
      return {
        msg: ''
      }
    }
  }
</script>
