<template>
  <div class="site-footer">
    <div class="footer-btmbar-bg">
      <div class="footer-btmbar-inner">
        <div class="footer-service">
          <a class="f-service-a">
            <i class="icont">1</i>
            预约维修
          </a>
          <a class="f-service-a">
            <i class="icont">1</i>
            预约维修
          </a>
          <a class="f-service-a">
            <i class="icont">1</i>
            预约维修
          </a>
          <a class="f-service-a">
            <i class="icont">1</i>
            预约维修
          </a>
          <a class="f-service-a">
            <i class="icont">1</i>
            预约维修
          </a>
        </div>
        <div class="footer-links">
          <aside class="links-list">
            <dl class="f-links-dl">
              <dt class="f-links-dt">帮助中心</dt>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
            </dl>
            <dl class="f-links-dl">
              <dt class="f-links-dt">帮助中心</dt>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
            </dl>
            <dl class="f-links-dl">
              <dt class="f-links-dt">帮助中心</dt>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
            </dl>
            <dl class="f-links-dl">
              <dt class="f-links-dt">帮助中心</dt>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
            </dl>
            <dl class="f-links-dl">
              <dt class="f-links-dt">帮助中心</dt>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
              <dd class="f-links-dd"><a>大家来</a></dd>
            </dl>
          </aside>
          <address class="f-links-way">
            <p class="f-way-tel">400-100-5678</p>
            <time class="f-way-time"><span class="time-txt">周一至周日 8:00-18:00</span><span class="time-txt">（仅收市话费）</span></time>
            <a class="f-way-24h">24小时在线客服</a>
          </address>
        </div>
      </div>
    </div>
    <div class="footer-info">
      <div class="footer-info-copy">
        <div class="f-logo">djlcg官网</div>
        <div class="f-info-text">
          <p class="f-txt1">
            <a class="f-con">大家来商城</a>
            <span class="sep">|</span>
            <a class="f-con">MIUI</a>
            <span class="sep">|</span>
            <a class="f-con">大家来</a>
            <span class="sep">|</span>
            <a class="f-con">多看书城</a>
            <span class="sep">|</span>
            <a class="f-con">大家来路由器</a>
            <span class="sep">|</span>
            <a class="f-con">视频电话</a>
            <span class="sep">|</span>
            <a class="f-con">大家来天猫店</a>
            <span class="sep">|</span>
            <a class="f-con">大家来直营店</a>
            <span class="sep">|</span>
            <a class="f-con">大家来网盟</a>
            <span class="sep">|</span>
            <a class="f-con">大家来移动</a>
            <span class="sep">|</span>
            <a class="f-con">隐私政策</a>
            <span class="sep">|</span>
            <a class="f-con">Select Regio</a>
          </p>
          <p class="f-txt2">
            <a class="f-con">©mi.com</a>
            <a class="f-con">京ICP证110507号</a>
            <a class="f-con">京ICP备10046444号</a>
            <a class="f-con">京公网安备11010802020134号</a>
            <a class="f-con">京网文[2014]0059-0009号</a><br>
            <span class="f-con">违法和不良信息举报电话：185-0130-1238，本网站所列数据，除特殊说明，所有数据均出自我司实验室测试</span>
          </p>
        </div>
        <div class="f-info-links">
          <a class="f-follow"><img src="../../../assets/images/truste.png"></a>
          <a class="f-follow"><img src="../../../assets/images/truste.png"></a>
          <a class="f-follow"><img src="../../../assets/images/truste.png"></a>
          <a class="f-follow"><img src="../../../assets/images/truste.png"></a>
        </div>
      </div>
      <div class="f-info-btm">探索黑科技，大家来为发安全而生</div>
    </div>
  </div>
</template>

<style lang="less">
  @import "../../../assets/css/site-header.less";
</style>
