import { HIDEDIALOG } from './mutations-types'

export const hideDialog = ({ dispatch }) => dispatch(HIDEDIALOG)
