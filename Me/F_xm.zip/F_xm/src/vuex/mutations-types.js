export const HIDEDIALOG = 'HIDEDIALOG'
