exports.isEmptyObject = function(e) {
    var t;
    for (t in e)
        return !1;
    return !0
}