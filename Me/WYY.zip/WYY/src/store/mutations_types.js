//注册窗口显示
export const SIGN_UP = 'SIGN_UP';


export const SERVER_SHOW = 'SERVER_SHOW';