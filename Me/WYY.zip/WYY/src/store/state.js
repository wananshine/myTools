export default {
    singUp: false,
    serverShow: false,
}