# sls-vuex2-demo

> 这是用vuex2实现的一个商城购物车demo,存储数据用的本地localstorage

## 演示

### GitHub：[https://sailengsi.github.io/sls-vuex2-demo/dist/](https://sailengsi.github.io/sls-vuex2-demo/dist/)
### Gitee：[https://sailengsi.gitee.io/sls-vuex2-demo/dist/](https://sailengsi.gitee.io/sls-vuex2-demo/dist/)
### Coding：[https://sailengsi.coding.me/sls-vuex2-demo/dist/](https://sailengsi.coding.me/sls-vuex2-demo/dist/)

## 操作步骤

``` bash
# 克隆项目
git clone https://github.com/sailengsi/sls-vuex2-demo.git

# 安装依赖
npm install

# 启动server
npm run dev

# 编译发布
npm run build
```
